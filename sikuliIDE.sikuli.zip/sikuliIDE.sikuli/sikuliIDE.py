
from guide import *

#Star game by clicking desktop icon
doubleClick("Blast.png")
wait(5)

wait("waitFor.png")

#Accessing Settings Menu

menu = find("PNewGame.png")
menu.highlight(4)

text("menu.png", "This is the menu")
show(3)

wait(3)
click("settings.png")
wait(2)


levels = find("PHUUIL.png")
levels.highlight(2)

text("dificulty.png", "This is the dificulty level selector")
show(2)

wait(2)

text("language.png", "This is the language Selector")


click("intermediate.png")
wait(2)

click("advanced.png")
wait(2)

click("beginer.png")

wait(2)

click("auto.png")

wait(2)

click("1.png")
wait(2)
click("1.png")
wait(2)
click("1.png")
wait(2)
click("1.png")
wait(2)



hover("france.png")
wait(1)

hover("germany.png")
wait(1)

hover("italy.png")
wait(2)

hover("portuguese.png")
wait(2)

click("scores.png")

wait(2)

dragDrop("bar-1.png", "bar2-1.png")
print("###############################################")
print("Settings Test OK- All the components were found")
print("###############################################")

wait(4)

if exists("GAME-1.png"):
    print("###############################")
    print("Starting Game Test")
    print("###############################")
    click("GAME3.png")
    
else :
    print("Can not start Game")
    

wait(4)


type(Key.SPACE); wait(0.1)



#Random GamePlay actions

type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.DOWN); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.UP); wait(0.1)
type(Key.LEFT); wait(0.1)
type(Key.DOWN); wait(0.1)

print("###############################")
print("Playtesting completed")
print("###############################")
